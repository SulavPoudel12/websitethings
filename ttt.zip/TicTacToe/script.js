function reset(){
    location.reload()
    console.log('hi')
  }
  gameBoxes = document.querySelectorAll(".gameBox");
  turnarr = ["X", "O"];
  turn = turnarr[0];
  a = 2;
  Over = document.getElementById("gameBar");
  PlayerX = document.getElementById('playerX')
  PlayerO = document.getElementById('playerO')
  gamerun = document.getElementById('rungame')
  
  WinConditions = [
    ["1", "2", "3"],
    ["4", "5", "6"],
    ["7", "8", "9"],
    ["1", "4", "7"],
    ["2", "5", "8"],
    ["3", "6", "9"],
    ["1", "5", "9"],
    ["3", "5", "7"],
  ];
  count = 0;
  gameinfo = document.getElementById("gameinfo");
  whowon = document.getElementById("whowon");
  gameBoxes.item.disabled = false;
  for (item of gameBoxes) {
    item.addEventListener("click", (e) => {
      
      if (e.target.disabled == false) {
        e.target.innerText = turn;
        a += 1;
        turn = turnarr[a % 2];
        if (turn == "X") {
          PlayerX.style.background = 'rgba(255, 255, 255, 0.76)'
          PlayerO.style.background = 'none'
          PlayerX.style.color = 'black'
          PlayerO.style.color = 'white'
        }
        else if (turn == "O") {
          PlayerO.style.background ='rgba(255, 255, 255, 0.76)'
          PlayerX.style.background ='none'
          PlayerO.style.color ='black'
          PlayerX.style.color ='white'
        }
        e.target.disabled = true;
        count += 1;
        console.log(count);

        for (let index = 0; index < WinConditions.length; index++) {
          gameX =
            document.getElementById(WinConditions[index][0]).innerText +
            document.getElementById(WinConditions[index][1]).innerText +
            document.getElementById(WinConditions[index][2]).innerText +
            "X";

          gameO =
            document.getElementById(WinConditions[index][0]).innerText +
            document.getElementById(WinConditions[index][1]).innerText +
            document.getElementById(WinConditions[index][2]).innerText +
            "O";

          if (gameX == "XXXX") {
            setTimeout(() => {
              
              Over.style.display = "inline";
              gamerun.style.display = "none"
            }, 1000);
            gameinfo.innerText = "Game Over";
            whowon.innerText = '"X" Won';
            count == 9
            
            
            break;
          } else if (gameO == "OOOO") {
            setTimeout(() => {
              
              gamerun.style.display = "none"
              Over.style.display = "inline";
            }, 1000);
            gameinfo.innerText = "Game Over";
            whowon.innerText = '"O" Won';
            count == 9
            break;
          } else if (count == 9) {
           setTimeout(() => {
            gamerun.style.display = "none"
            Over.style.display = "inline";
           }, 50);
            gameinfo.innerText = "Game Draw";
            whowon.innerText = "Both Won Both Loose";
          }
        }
      }
    })
  }

